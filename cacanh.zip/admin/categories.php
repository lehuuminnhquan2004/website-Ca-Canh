<?php
session_start();
if (empty($_SESSION['admin_id'])) {
    header("Location: /admin/login.php");
    exit;
}
include __DIR__ . '/../includes/db.php';

// Xóa danh mục (nên kiểm tra không có sản phẩm trước khi xóa)
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    mysqli_query($conn, "DELETE FROM categories WHERE id=$id");
    header("Location: /admin/categories.php");
    exit;
}

// Lấy giá trị tìm kiếm nếu có
$searchKeyword = isset($_GET['search']) ? trim($_GET['search']) : '';

// Lấy danh sách danh mục
$sql = "SELECT * FROM categories WHERE 1";
if ($searchKeyword !== '') {
    $searchEscaped = mysqli_real_escape_string($conn, $searchKeyword);
    $sql .= " AND name LIKE '%$searchEscaped%'";
}
$sql .= " ORDER BY name ASC";

$res = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Quản lý danh mục</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  
<?php include __DIR__ . '/admin-header.php'; ?>

<div class="container">
  <div style="margin-bottom:10px; display:flex; justify-content:space-between; flex-wrap:wrap;">
    <a class="btn" href="./category-form.php">+ Thêm danh mục</a>
    <form method="get" style="display:flex; gap:5px;">
      <input type="text" name="search" placeholder="Tìm theo tên..." value="<?= htmlspecialchars($searchKeyword) ?>">
      <button type="submit" class="btn">Tìm</button>
      <?php if ($searchKeyword !== ''): ?>
        <a href="./categories.php" class="btn">Reset</a>
      <?php endif; ?>
    </form>
  </div>

  <div class="table-wrapper">
    <table class="table">
      <tr>
        <th>ID</th>
        <th>Tên danh mục</th>
        <th>Slug</th>
        <th>Hành động</th>
      </tr>
      <?php if(mysqli_num_rows($res) === 0): ?>
        <tr>
          <td colspan="4">Không tìm thấy danh mục nào.</td>
        </tr>
      <?php else: ?>
        <?php while ($row = mysqli_fetch_assoc($res)) : ?>
          <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['slug']) ?></td>
            <td>
              <a href="./category-form.php?id=<?= $row['id'] ?>">Sửa</a> |
              <a href="./categories.php?delete=<?= $row['id'] ?>"
                 onclick="return confirm('Xóa danh mục này?');">Xóa</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php endif; ?>
    </table>
  </div>
</div>
</body>
</html>
