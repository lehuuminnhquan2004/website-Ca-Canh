<?php
$page_title = "Sản phẩm - Cửa hàng cá cảnh";
include __DIR__ . '/includes/db.php';
include __DIR__ . '/includes/header.php';

// Lấy danh sách danh mục
$sql_categories = "SELECT * FROM categories ORDER BY name ASC";
$cat_res = mysqli_query($conn, $sql_categories);
$categories = [];
while ($row = mysqli_fetch_assoc($cat_res)) {
    $categories[] = $row;
}

// --- Lấy danh mục được chọn ---
$selectedCategoryId = isset($_GET['category_id']) ? (int) $_GET['category_id'] : 0;

// Lấy tên danh mục được chọn
$selectedCategoryName = '';
if ($selectedCategoryId > 0) {
    foreach ($categories as $c) {
        if ((int)$c['id'] === $selectedCategoryId) {
            $selectedCategoryName = $c['name'];
            break;
        }
    }
}

// Tìm kiếm theo tên
// Phân trang
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$searchKeyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';

// Sắp xếp
$sortOption = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

// Base query
$sql_products = "SELECT * FROM products WHERE 1";
// Query đếm tổng
$sql_count = "SELECT COUNT(*) as total FROM products WHERE 1";

// Lọc theo danh mục
if ($selectedCategoryId > 0) {
    $sql_products .= " AND category_id = $selectedCategoryId";
    $sql_count    .= " AND category_id = $selectedCategoryId";
}

// Tìm kiếm theo tên
if ($searchKeyword !== '') {
    $keywordEscaped = mysqli_real_escape_string($conn, $searchKeyword);
    $sql_products .= " AND name LIKE '%$keywordEscaped%'";
    $sql_count    .= " AND name LIKE '%$keywordEscaped%'";
}

// Sắp xếp
switch ($sortOption) {
    case 'price_asc':
        $sql_products .= " ORDER BY price ASC";
        break;
    case 'price_desc':
        $sql_products .= " ORDER BY price DESC";
        break;
    case 'name_asc':
        $sql_products .= " ORDER BY name ASC";
        break;
    case 'name_desc':
        $sql_products .= " ORDER BY name DESC";
        break;
    default: // newest
        $sql_products .= " ORDER BY created_at DESC";
        break;
}

// Phân trang: giới hạn và offset
$sql_products .= " LIMIT $perPage OFFSET $offset";

// Tổng số sản phẩm
$total = 0;
$countRes = mysqli_query($conn, $sql_count);
if ($countRes) {
    $total = (int) mysqli_fetch_assoc($countRes)['total'];
}
$totalPages = max(1, (int) ceil($total / $perPage));

$prod_res = mysqli_query($conn, $sql_products);
$products = [];
while ($p = mysqli_fetch_assoc($prod_res)) {
    $products[] = $p;
}
?>


<div class="tentrang"><h2>Sản phẩm</h2></div>
<link rel="stylesheet" href="./assets/css/products.css">

<div class="filter-box">
  <form method="get" id="filterForm">
    <div class=form-loc>
        <div class="timkiem">
            <!-- Tìm kiếm -->
            <input 
            type="text" 
            name="keyword" 
            placeholder="Tìm sản phẩm..." 
            value="<?= htmlspecialchars($searchKeyword) ?>"
            >
        </div>

        <!-- Chọn danh mục -->
        <div class="chondanhmuc">
            <select name="category_id" onchange="document.getElementById('filterForm').submit()">
            <option value="0">-- Tất cả danh mục --</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= ($selectedCategoryId == $cat['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat['name']) ?>
                </option>
            <?php endforeach; ?>
            </select>
        </div>

        <!-- Sắp xếp -->
        <div class="sapxep">
            <select name="sort" onchange="document.getElementById('filterForm').submit()">
            <option value="newest" <?= $sortOption=='newest'?'selected':'' ?>>Mới nhất</option>
            <option value="price_asc" <?= $sortOption=='price_asc'?'selected':'' ?>>Giá tăng dần</option>
            <option value="price_desc" <?= $sortOption=='price_desc'?'selected':'' ?>>Giá giảm dần</option>
            <option value="name_asc" <?= $sortOption=='name_asc'?'selected':'' ?>>Tên A → Z</option>
            <option value="name_desc" <?= $sortOption=='name_desc'?'selected':'' ?>>Tên Z → A</option>
            </select>
        </div>
        <button type="submit">Lọc</button>
    </div>

  </form>
</div>


<?php if (empty($products)): ?>
    <p>Hiện chưa có sản phẩm nào.</p>
<?php else: ?>
    <?php if ($selectedCategoryId > 0): ?>
        <h2>Sản phẩm trong danh mục: <?= htmlspecialchars($selectedCategoryName) ?></h2>
    <?php endif; ?>
    <div class="grid">
        <?php foreach ($products as $row): ?>
            <?php
                $imgFile = !empty($row['thumbnail']) ? $row['thumbnail'] : ($row['image'] ?? '');
                if ($imgFile && !preg_match('#^https?://#', $imgFile) && !str_starts_with($imgFile, '/')) {
                    if (!str_starts_with($imgFile, './')) {
                        $imgFile = './' . ltrim($imgFile, '/');
                    }
                }
                $imgSrc = $imgFile ?: './images/logo/logo.png';
            ?>
            <a class="card" href="product.php?slug=<?= urlencode($row['slug']) ?>">
                <?php if ($imgSrc): ?>
                    <img src="<?= htmlspecialchars($imgSrc) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
                <?php endif; ?>
                <h3><?= htmlspecialchars($row['name']) ?></h3>
                <p><strong><?= number_format($row['price']) ?> đ</strong></p>
            </a>
        <?php endforeach; ?>
    </div>
    <?php if ($totalPages > 1): ?>
      <div class="pagination">
        <?php
          $queryBase = $_GET;
          // Prev
          if ($page > 1) {
            $queryBase['page'] = $page - 1;
            $link = '?' . http_build_query($queryBase);
            echo '<a class="page-link prev" href="'.$link.'">Prev</a>';
          }
          // Numbers
          for ($i = 1; $i <= $totalPages; $i++):
            $queryBase['page'] = $i;
            $link = '?' . http_build_query($queryBase);
        ?>
            <a class="page-link <?= $i === $page ? 'active' : '' ?>" href="<?= $link ?>"><?= $i ?></a>
        <?php endfor;
          // Next
          if ($page < $totalPages) {
            $queryBase['page'] = $page + 1;
            $link = '?' . http_build_query($queryBase);
            echo '<a class="page-link next" href="'.$link.'">Next</a>';
          }
        ?>
      </div>
    <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
