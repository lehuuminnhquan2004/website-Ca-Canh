﻿<?php
$page_title = "Trang chủ - Cửa hàng cá cảnh";
include __DIR__ . '/includes/db.php';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/banner.php';

// Đọc cấu hình sản phẩm nổi bật
$configPath = __DIR__ . '/includes/site-config.json';
$featuredIds = [];
if (file_exists($configPath)) {
    $cfg = json_decode(file_get_contents($configPath), true);
    if (!empty($cfg['featured_products']) && is_array($cfg['featured_products'])) {
        $featuredIds = array_values(array_unique(array_map('intval', $cfg['featured_products'])));
    }
}

// Lấy danh sách sản phẩm cho mục "Sản phẩm mới"
if (!empty($featuredIds)) {
    $idList = implode(',', $featuredIds);
    $productRes = mysqli_query(
        $conn,
        "SELECT * FROM products WHERE id IN ($idList) ORDER BY FIELD(id, $idList)"
    );
} else {
    $productRes = mysqli_query($conn, "SELECT * FROM products ORDER BY created_at DESC LIMIT 6");
}
$products = [];
if ($productRes) {
    while ($row = mysqli_fetch_assoc($productRes)) {
        $products[] = $row;
    }
}

// Lấy 3 bài viết mới nhất
$blogRes = mysqli_query($conn, "SELECT * FROM blog_posts ORDER BY created_at DESC LIMIT 3");
$blogs = [];
if ($blogRes) {
    while ($row = mysqli_fetch_assoc($blogRes)) {
        $blogs[] = $row;
    }
}
?>



 


<section class="sanphammoi">
  <h2>Sản phẩm mới</h2>
  <?php if (empty($products)): ?>
    <p>Chưa có sản phẩm.</p>
  <?php else: ?>
    <div class="product-grid">
      <?php foreach ($products as $row): ?>
        <?php
          $imgFile = !empty($row['image']) ? $row['image'] : ($row['thumbnail'] ?? '');
          $imgSrc = $imgFile ? $imgFile : "./images/logo/logo.png";
        ?>
        <a class="product-card" href="product.php?slug=<?= urlencode($row['slug']) ?>">
          <div class="thumb">
            <img src="<?= htmlspecialchars($imgSrc) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
          </div>
          <div class="info">
            <h3><?= htmlspecialchars($row['name']) ?></h3>
            <p class="price"><?= number_format($row['price'], 0, ',', '.') ?> VND</p>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <p style="text-align: center; margin-top: 20px;">
    <a class="button-outline primary" href="products.php">Xem tất cả sản phẩm</a>
  </p>
</section>

<section class="knowledge-section">
  <h2>Kiến thức hữu ích</h2>
  <p class="sub">Tổng hợp bài viết hướng dẫn nuôi cá, chăm sóc hồ, xử lý bệnh, setup thuỷ sinh...</p>

  <div class="knowledge-grid">
    <?php if (empty($blogs)): ?>
      <p>Chưa có bài viết.</p>
    <?php else: ?>
      <?php foreach ($blogs as $row): ?>
        <?php
          $thumbFile = !empty($row['thumbnail']) ? $row['thumbnail'] : '';
          $thumbSrc = $thumbFile ? "./images/blog/" . $thumbFile : "./images/icons/icon-zalo.png";
          $summary = trim($row['summary']);
          if (mb_strlen($summary) > 90) {
              $summary = mb_substr($summary, 0, 90) . '...';
          }
        ?>
        <a class="knowledge-card" href="blog_detail.php?slug=<?= urlencode($row['slug']) ?>">
          <div class="thumb">
            <img src="<?= htmlspecialchars($thumbSrc) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
          </div>
          <div class="info">
            <h3><?= htmlspecialchars($row['title']) ?></h3>
            <p><?= htmlspecialchars($summary) ?></p>
          </div>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <p style="text-align: center; margin-top: 20px;">
    <a class="button-outline primary" href="blog.php">Xem tất cả bài viết</a>
  </p>
</section>
<script>

  
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
